import React, { useRef, useEffect } from "react";
// import VanillaTilt from "vanilla-tilt";

//https://micku7zu.github.io/vanilla-tilt.js/

const Tilt = props => {
  return <div className="custom-tilt" />;
};

export default Tilt;
