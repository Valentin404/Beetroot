import React from "react";
import Messages from "./components/Messages";

const App = () => (
  <div className="container">
    <Messages />
  </div>
);

export default App;
