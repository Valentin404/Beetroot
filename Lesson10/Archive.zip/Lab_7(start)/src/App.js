import React from "react";
import Counter from "./components/Counter";

const App = props => (
  <div className="container pt-3">
    <Counter />
  </div>
);

export default App;
