import React from "react";
import Users from "./components/Users";

const App = (props) => (
  <div className="container pt-3">
    <Users />
  </div>
);

export default App;
