import React, { useState, useEffect } from "react";

// "https://swapi.dev/api/"

const Users = (props) => {

  return (
    <div className="col-4">
    </div>
  );
};

export default Users;
