import React from "react";

const App = props => (
    <div className="container">
    </div>
);

export default App;
