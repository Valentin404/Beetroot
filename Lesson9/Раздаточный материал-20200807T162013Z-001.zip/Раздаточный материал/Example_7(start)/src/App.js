import React from "react";

const App = () => (
  <div className="container">
  </div>
);

export default App;
